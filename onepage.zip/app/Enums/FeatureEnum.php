<?php 

namespace App\Enums;

enum FeatureEnum : string {
    case Active = 'Active';
    case Inactive = 'Inactive';
}

?>